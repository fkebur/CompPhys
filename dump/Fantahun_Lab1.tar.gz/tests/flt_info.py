# Computational Physics - Lab 1
# Part 1
# Kebur Fantahun

import sys

# Find the largest float
print( "The largest float is... ", sys.float_info.max)

# Find the smallest float
print( "The smallest float is... ", sys.float_info.min)

# Find the machine precision
print( "The machine precision is... ", sys.float_info.epsilon)
