#ifndef HELLOWORLD2_H_
#define HELLOWORLD2_H_

#include "HelloWorld.h"

class HelloWorld2 : public HelloWorld
{
public:
    void gets(double& s_) const;
};

#endif // HELLOWORLD2_H_
