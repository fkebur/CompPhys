#!/usr/bin/python

W = 0.01 # m ; keep in mind transferring (units of length) cm - > mm - > to grid points
D = 0.044
L = 0.03


