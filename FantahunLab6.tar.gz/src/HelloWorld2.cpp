#include "HelloWorld2.h"

void HelloWorld2::gets(double& in) const
{ 
    in = s;
}
